package objeto;

public class Funcionario extends Pessoa{
    String matriculaF;
    public Funcionario(String nome, int idade, String cpf, String matriculaF){
        super(nome, idade, cpf);
        this.matriculaF = matriculaF;
    }

    public String getMatriculaF() {
        return matriculaF;
    }

    public void setMatriculaF(String matriculaF) {
        this.matriculaF = matriculaF;
    }
    
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
